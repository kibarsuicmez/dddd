<template>
  <div class="h-screen w-screen flex flex-col bg-[#343541] text-[#ececf1] font-sans">
    <!-- Top bar -->
    <header class="flex items-center justify-between h-12 border-b border-[#40414F] px-3 bg-[#343541] relative select-none">
      <button class="text-gray-300 hover:text-gray-200 transition">
        <img src="/assets/logo.png" alt="logo" style="width: 35px;height: 35px" />
      </button>

      <div class="absolute left-1/2 -translate-x-1/2 text-sm font-medium">
        Insight AI Assistant
      </div>

      <div class="w-5"></div>
    </header>

    <!-- Messages area -->
    <div class="flex-1 overflow-y-auto pb-32">
      <div class="flex justify-center">
        <div class="max-w-3xl w-full px-4 pt-6 space-y-4">
          <div
            v-for="(msg, index) in messages"
            :key="index"
            :class="[
              'rounded-lg p-4 leading-relaxed',
              msg.role === 'assistant' ? 'bg-[#444654]' : 'bg-[#202123]'
            ]"
          >
            <div class="prose prose-invert max-w-none" v-html="msg.html"></div>
          </div>
        </div>
      </div>
    </div>

    <!-- Input area -->
    <div class="fixed bottom-0 w-full border-t border-[#40414F] bg-[#40414F]">
      <form @submit.prevent="onSubmit" class="max-w-3xl mx-auto px-4 py-2 flex items-end space-x-2">
        <div class="flex-1 relative">
          <textarea
            v-model="userMessage"
            rows="1"
            placeholder="Ask a message..."
            class="w-full rounded-md px-3 py-2 bg-[#343541] text-[#ececf1] placeholder-[#8e8ea0]
                   focus:outline-none focus:ring-1 focus:ring-indigo-500 resize-none leading-relaxed"
            @input="autoResize"
          ></textarea>
        </div>
        <button
          type="submit"
          class="p-2 rounded-full hover:bg-[#2f3035] text-gray-300 hover:text-gray-100 transition"
        >
          <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 rotate-45"
               fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
            <path stroke-linecap="round" stroke-linejoin="round"
                  d="M10.5 6.75L3.75 12l6.75 5.25M3.75 12h16.5"/>
          </svg>
        </button>
      </form>
    </div>
  </div>
</template>

<script setup>
import { ref, nextTick, watch } from 'vue'
import { marked } from 'marked'
import hljs from 'highlight.js'
import 'highlight.js/styles/github-dark.css'
import { KendraClient, QueryCommand } from "@aws-sdk/client-kendra";

marked.setOptions({})

// Mock function to simulate calling AWS Bedrock.
async function callBedrock(userInput) {

    try {
      const client = new KendraClient({
        region: 'ap-southeast-2' // Set your region
      });

      const params = {
        IndexId: "d8b72045-a061-45fe-86b5-2d696ce887ce",
        QueryText: userInput,
        PageSize: 10, // Adjust as needed
      };

        const command = new QueryCommand(params);
        const response = await client.send(command);
        this.results = response.ResultItems || [];

      const kendraData = await kendraResponse.json();

      const results = kendraData.ResultItems;
      const assistantMsg = { role: 'assistant', content: results }
      messages.value.push(assistantMsg)
      // Simulate a delay and then return a structured answer

      return results
    } catch (error) {
      const assistantMsg = { role: 'assistant', content: error.message }
      messages.value.push(assistantMsg)

    }
  // const response = await fetch('/bedrock-endpoint', { method: 'POST', body: JSON.stringify({ prompt: userInput }) })
  // const data = await response.json()
  // return data.result




}

const userMessage = ref('')
const messages = ref([
  {
    role: 'assistant',
    content: "Hello! I’m insight AI assistant. How can I help you today?",
    html: marked("Hello! I’m insight AI assistant. How can I help you today?")
  }
])

// After messages change and DOM updates, highlight code blocks
watch(messages, async () => {
  await nextTick()
  document.querySelectorAll('pre code').forEach((block) => {
    hljs.highlightElement(block)
  })
}, { deep: true })

const onSubmit = async () => {
  const question = userMessage.value.trim()
  if (!question) return


  // Add user’s message immediately
  const userMsg = { role: 'user', content: question, html: marked(question) }
  messages.value.push(userMsg)
  userMessage.value = ''

  // Call Bedrock
  const answer = await callBedrock(question)
  const assistantMsg = { role: 'assistant', content: answer }
  messages.value.push(assistantMsg)
}

const autoResize = (e) => {
  const textarea = e.target
  textarea.style.height = 'auto'
  textarea.style.height = textarea.scrollHeight + 'px'
}
</script>


<style>
body {
  font-family: Inter, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
}
</style>
