<template>
  <div class="max-w-3xl mx-auto w-full">
    <div :class="messageClass">
      <div class="whitespace-pre-wrap break-words">
        {{ content }}
      </div>
    </div>
  </div>
</template>

<script setup>
import { computed } from 'vue'

const props = defineProps({
  content: { type: String, required: true },
  role: {
    type: String,
    default: 'assistant', // 'assistant' or 'user'
    validator: (val) => ['assistant', 'user'].includes(val)
  }
})

const isUser = computed(() => props.role === 'user')

const messageClass = computed(() => [
  'px-4',       // horizontal padding
  'py-4',       // vertical padding
  'rounded-lg', // rounded corners
  'mb-4',       // spacing between messages
  isUser.value ? 'bg-[#202123]' : 'bg-[#444654]',
  'text-[#ececf1]', // off-white text
  'leading-relaxed'
])
</script>
