<template>
  <div class="h-screen w-screen flex flex-col bg-[#343541] text-white font-sans">
    <!-- Header (Top Bar) -->
    <header class="shrink-0 flex items-center justify-between px-4 h-14 border-b border-[#40414F] bg-[#343541]">
      <div class="flex items-center space-x-2">
        <div class="font-semibold text-base">New chat</div>
      </div>
      <div class="flex items-center space-x-3">
        <!-- Placeholder icons, replace with actual icons if needed -->
        <button class="text-gray-300 hover:text-gray-200 transition">
          <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none"
               viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
            <path stroke-linecap="round" stroke-linejoin="round"
                  d="M3 7h18M3 11h18M3 15h18M3 19h18"/>
          </svg>
        </button>
        <button class="text-gray-300 hover:text-gray-200 transition">
          <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none"
               viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
            <path stroke-linecap="round" stroke-linejoin="round"
                  d="M4 6h16M4 12h8m-8 6h16"/>
          </svg>
        </button>
      </div>
    </header>

    <!-- Chat scrollable area -->
    <div class="flex-1 overflow-y-auto px-0 pb-32">
      <!-- Example of an assistant message -->
      <div class="w-full flex justify-center">
        <div class="max-w-3xl w-full px-4 pt-6">
          <div class="bg-[#444654] text-[#ececf1] rounded-lg p-4 mb-4 leading-relaxed">
            Hello! I’m ChatGPT. How can I help you today?
          </div>
        </div>
      </div>

      <!-- Example of a user message -->
      <div class="w-full flex justify-center">
        <div class="max-w-3xl w-full px-4">
          <div class="bg-[#202123] text-[#ececf1] rounded-lg p-4 mb-4 leading-relaxed">
            Can you show me how to replicate your interface using Vue 3 and Tailwind?
          </div>
        </div>
      </div>

      <!-- Another assistant message -->
      <div class="w-full flex justify-center">
        <div class="max-w-3xl w-full px-4">
          <div class="bg-[#444654] text-[#ececf1] rounded-lg p-4 mb-4 leading-relaxed">
            Sure! Here’s an example...
          </div>
        </div>
      </div>
    </div>

    <!-- Input area -->
    <div class="fixed bottom-0 w-full bg-transparent">
      <div class="border-t border-[#40414F] bg-[#40414F] px-4 py-3">
        <form @submit.prevent="onSubmit" class="max-w-3xl mx-auto flex items-end space-x-2">
          <div class="flex-1">
            <textarea
              v-model="userMessage"
              rows="1"
              placeholder="Send a message..."
              class="w-full rounded-md px-3 py-2 bg-[#343541] text-[#ececf1] placeholder-[#8e8ea0]
                     focus:outline-none focus:ring-1 focus:ring-indigo-500 resize-none leading-relaxed"
              @input="autoResize"
            ></textarea>
          </div>
          <button
            type="submit"
            class="px-4 py-2 bg-indigo-600 text-white font-medium rounded-md hover:bg-indigo-500 transition-colors"
          >
            Send
          </button>
        </form>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'

const userMessage = ref('')

const onSubmit = () => {
  // Handle message sending logic here
  console.log('User message:', userMessage.value)
  userMessage.value = ''
}

const autoResize = (e) => {
  const textarea = e.target
  textarea.style.height = 'auto'
  textarea.style.height = textarea.scrollHeight + 'px'
}

onMounted(() => {
  // Optional: Adjust textarea height on load if needed
})
</script>

<style>
html, body {
  margin: 0;
  padding: 0;
  background: #343541;
  font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
}
</style>
